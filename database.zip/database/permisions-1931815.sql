GRANT USAGE ON *.* TO `user-1931815`@`localhost` IDENTIFIED BY PASSWORD '*866D936E7D27A5F3C4BB6DBD09B8CC4052220297';
GRANT SELECT ON `database-1931815`.`purchases_fulldate_view` TO `user-1931815`@`localhost` WITH GRANT OPTION;
GRANT EXECUTE ON PROCEDURE `database-1931815`.`products_update` TO `user-1931815`@`localhost` WITH GRANT OPTION;
GRANT EXECUTE ON PROCEDURE `database-1931815`.`customers_select_all` TO `user-1931815`@`localhost` WITH GRANT OPTION;
GRANT EXECUTE ON PROCEDURE `database-1931815`.`products_select_all` TO `user-1931815`@`localhost` WITH GRANT OPTION;
GRANT EXECUTE ON PROCEDURE `database-1931815`.`products_insert` TO `user-1931815`@`localhost` WITH GRANT OPTION;
GRANT EXECUTE ON PROCEDURE `database-1931815`.`products_select_one` TO `user-1931815`@`localhost` WITH GRANT OPTION;
GRANT EXECUTE ON PROCEDURE `database-1931815`.`purchases_delete` TO `user-1931815`@`localhost` WITH GRANT OPTION;
GRANT EXECUTE ON PROCEDURE `database-1931815`.`customers_insert` TO `user-1931815`@`localhost` WITH GRANT OPTION;
GRANT EXECUTE ON PROCEDURE `database-1931815`.`filter_by_date` TO `user-1931815`@`localhost` WITH GRANT OPTION;
GRANT EXECUTE ON PROCEDURE `database-1931815`.`products_delete` TO `user-1931815`@`localhost` WITH GRANT OPTION;
GRANT EXECUTE ON PROCEDURE `database-1931815`.`purchases_select_one` TO `user-1931815`@`localhost` WITH GRANT OPTION;
GRANT EXECUTE ON PROCEDURE `database-1931815`.`customers_delete` TO `user-1931815`@`localhost` WITH GRANT OPTION;
GRANT EXECUTE ON PROCEDURE `database-1931815`.`purchases_insert` TO `user-1931815`@`localhost` WITH GRANT OPTION;
GRANT EXECUTE ON PROCEDURE `database-1931815`.`login` TO `user-1931815`@`localhost` WITH GRANT OPTION;
GRANT EXECUTE ON PROCEDURE `database-1931815`.`purchases_update` TO `user-1931815`@`localhost` WITH GRANT OPTION;
GRANT EXECUTE ON PROCEDURE `database-1931815`.`customers_update` TO `user-1931815`@`localhost` WITH GRANT OPTION;
GRANT EXECUTE ON PROCEDURE `database-1931815`.`customers_select_one` TO `user-1931815`@`localhost` WITH GRANT OPTION;
GRANT EXECUTE ON PROCEDURE `database-1931815`.`purchases_select_all` TO `user-1931815`@`localhost` WITH GRANT OPTION;


